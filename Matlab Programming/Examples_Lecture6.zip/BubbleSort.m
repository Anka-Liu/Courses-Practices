function v = BubbleSort(v)
% An implementation of the bubble sort algorithm. This is very inefficient
% for large inputs.

swapped = true;

while swapped  % Repeat until no elements have been swapped
    swapped = false;
    for i=1:(length(v)-1) % Search list for a pair that are not in order        
        if v(i)>v(i+1)
            % Swap v(i) and v(i+1)
            v([i+1, i]) = v([i, i+1]);
            swapped = true;
        end
    end
    plot(v,'k.');
    drawnow;
end
