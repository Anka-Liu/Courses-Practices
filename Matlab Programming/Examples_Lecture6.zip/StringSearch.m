function positions = StringSearch(string,pattern)
% Return the starting position of all matches of pattern in string

% This is a naive string searching algorithm. 
% Look up "Boyer-Moore algorithm" for a more efficient algorithm.

positions = [];

for i=1:(length(string)-length(pattern)+1)
    startpos = i;
    endpos =  (i+length(pattern)-1);
    substring = string(startpos:endpos); % get the substring starting at i that has the same length as pattern
    
    if strcmp(substring,pattern)      % check if substring matches pattern  
        positions(end+1) = startpos;
    end
end
