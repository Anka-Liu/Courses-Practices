function v = InsertionSort(v)
% A simple implementation of insertion-sort. This algorithm is inefficient
% for large arrays.

for i=1:(length(v)-1)
    % All elements up to position i will be in ascending order
    
    % Find the correct position for v(i+1) in the sorted part of the list
    % by traveling back down the list, and repeatedly swapping it with
    % larger elements.
    for j=i:-1:1
        % The element that was originally at position i+1 is now at
        % position j+1
        if v(j) > v(j+1)
            % Swap v(j+1) and v(j) 
            v([j+1, j]) = v([j, j+1]);
        else
            % All elements up to j+1 are in order, 
            % so break out of inner loop
            break;
        end
    end
    plot(v,'k.');
    drawnow;
end
