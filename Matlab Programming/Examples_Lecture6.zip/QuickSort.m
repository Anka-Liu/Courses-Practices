function s = QuickSort(v)
% An implementation of the quick-sort algorithm, using recursive function calls

% WARNING: Using recursive function calls can be inefficient in MATLAB.
% This example is only for understanding the basic quicksort algorithm.

if length(v)<=1
    % In this case, v is already sorted
    s = v;
else
    % Use the first element of v as the "pivot"
    s = sub_quickSort(v(2:end),v(1));
end

function s = sub_quickSort(v,pivot)
v1 = v(v<=pivot);  % Get elements of v that are less than pivot
v2 = v(v>pivot);   % Get elements of v that are greater than pivot

% Sort v1 and v2, and combine them with pivot in the middle
s  = [QuickSort(v1), pivot, QuickSort(v2)];  
