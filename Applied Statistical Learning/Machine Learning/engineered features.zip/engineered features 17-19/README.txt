The features are engineered according to the "group project description" and "technical guidance".

"fastKlag" is the "%K(t)" in "technical guidance" and "fastDlag" is the "%D(t)" in "technical guidance".

Note that all features are lagged. 
(Because we are not allowed to use today's data to predict today's value, we move the whole data set one day forward.)

According to the "technical guidance" and if we take "lag" into consideration, engineered features are available from Day17.